package com.payye.os;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class HomeAppsAdapter extends RecyclerView.Adapter<HomeAppsAdapter.ViewHolder> {

    public interface OnAppActionListener {
        void onAppClick(AppInfo app);
        void onAppLongClick(AppInfo app);
    }

    private List<AppInfo> apps;
    private boolean isListMode;
    private boolean showIcons;
    private final OnAppActionListener listener;

    public HomeAppsAdapter(List<AppInfo> apps, boolean isListMode, boolean showIcons, OnAppActionListener listener) {
        this.apps = apps;
        this.isListMode = isListMode;
        this.showIcons = showIcons;
        this.listener = listener;
    }

    public void updateData(List<AppInfo> newApps, boolean isListMode, boolean showIcons) {
        this.apps = newApps;
        this.isListMode = isListMode;
        this.showIcons = showIcons;
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        return isListMode ? 1 : 0;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        int layoutRes = (viewType == 1) ? R.layout.item_app_list : R.layout.item_app_grid;
        View view = LayoutInflater.from(parent.getContext()).inflate(layoutRes, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AppInfo app = apps.get(position);
        holder.label.setText(app.label);
        if (showIcons) {
            holder.icon.setVisibility(View.VISIBLE);
            holder.icon.setImageDrawable(app.icon);
        } else {
            holder.icon.setVisibility(View.GONE);
        }

        holder.itemView.setOnClickListener(v -> listener.onAppClick(app));
        holder.itemView.setOnLongClickListener(v -> {
            listener.onAppLongClick(app);
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return apps != null ? apps.size() : 0;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView icon;
        final TextView label;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.ivAppIcon);
            label = itemView.findViewById(R.id.tvAppLabel);
        }
    }
}
