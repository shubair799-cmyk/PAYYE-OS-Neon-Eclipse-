package com.payye.os;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SettingsActivity extends AppCompatActivity {

    private PayyePrefs prefs;
    private LinearLayout settingsContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefs = new PayyePrefs(this);
        settingsContainer = findViewById(R.id.settingsContainer);
        ImageButton btnBack = findViewById(R.id.btnSettingsBack);
        btnBack.setOnClickListener(v -> finish());

        buildSettingsList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        buildSettingsList();
    }

    private void buildSettingsList() {
        settingsContainer.removeAllViews();

        // Appearance Section
        addSectionHeader("APPEARANCE & NEON ECLIPSE");
        addSettingRow("Wallpaper", formatWallpaperName(prefs.getWallpaper()), this::showWallpaperDialog);
        addSettingRow("Theme", formatThemeName(prefs.getTheme()), this::showThemeDialog);
        addSettingRow("Accent Colour", formatAccentName(prefs.getAccent()), this::showAccentDialog);
        addSettingRow("Clock Style", formatClockStyleName(prefs.getClockStyle()), this::showClockStyleDialog);

        // Layout & Grid Section
        addSectionHeader("HOME SCREEN & APP GRID");
        addSettingRow("Home Screen Layout", formatLayoutName(prefs.getHomeLayout()), this::showLayoutDialog);
        addSettingRow("App Icons on Home", prefs.isShowIcons() ? "Visible" : "Hidden (Text Only)", () -> {
            prefs.setShowIcons(!prefs.isShowIcons());
            buildSettingsList();
        });
        addSettingRow("Manage Home Screen Apps", prefs.getHomePackages().size() + " pinned apps", this::showManageHomeAppsDialog);

        // Focus Mode Section
        addSectionHeader("FOCUS MODE");
        String focusSubtitle = prefs.isFocusActive() ? "Active — Tap to exit" : "Off — Tap to start";
        addSettingRow("Focus Mode Status", focusSubtitle, this::toggleFocusFromSettings);
        addSettingRow("Distracting Apps to Hide", prefs.getDistractingPackages().size() + " apps selected", this::showDistractingAppsDialog);

        // Android System Shortcuts
        addSectionHeader("ANDROID SYSTEM SHORTCUTS");
        addSettingRow("Set Default Home Launcher", "Choose PAYYE OS as Home app", () -> openSystemSettings(Settings.ACTION_HOME_SETTINGS));
        addSettingRow("Notification Shade", "Expand Android notifications & quick settings", () -> AppRepository.expandNotificationShade(this));
        addSettingRow("Sound Settings", "Volume, ringtone & Do Not Disturb", () -> openSystemSettings(Settings.ACTION_SOUND_SETTINGS));
        addSettingRow("Wi-Fi Settings", "Manage wireless networks", () -> openSystemSettings(Settings.ACTION_WIFI_SETTINGS));
        addSettingRow("Bluetooth Settings", "Manage paired devices", () -> openSystemSettings(Settings.ACTION_BLUETOOTH_SETTINGS));
        addSettingRow("Android System Settings", "Open full device settings", () -> openSystemSettings(Settings.ACTION_SETTINGS));

        // Reset Section
        addSectionHeader("RESET");
        addSettingRow(getString(R.string.reset_defaults_title), getString(R.string.reset_defaults_desc), this::confirmResetDefaults);
    }

    private void addSectionHeader(String title) {
        TextView tv = new TextView(this);
        tv.setText(title);
        tv.setTextColor(getColor(R.color.neon_pink));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setLetterSpacing(0.1f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(4, dp(14), 4, dp(6));
        tv.setLayoutParams(lp);
        settingsContainer.addView(tv);
    }

    private void addSettingRow(String title, String subtitle, Runnable onClick) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.bg_surface_card);
        card.setPadding(dp(16), dp(13), dp(16), dp(13));
        card.setClickable(true);
        card.setFocusable(true);
        card.setOnClickListener(v -> onClick.run());

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(4), 0, dp(4));
        card.setLayoutParams(lp);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextColor(getColor(R.color.moonlight));
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        tvTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));

        TextView tvSub = new TextView(this);
        tvSub.setText(subtitle);
        tvSub.setTextColor(getColor(R.color.lavender));
        tvSub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tvSub.setPadding(0, dp(2), 0, 0);

        card.addView(tvTitle);
        card.addView(tvSub);
        settingsContainer.addView(card);
    }

    private void showWallpaperDialog() {
        String[] labels = {"Cosmic Eclipse (Default)", "Void Horizon", "Neon Nebula", "Pure Obsidian (Max Battery)"};
        String[] keys = {PayyePrefs.WALLPAPER_COSMIC, PayyePrefs.WALLPAPER_HORIZON, PayyePrefs.WALLPAPER_NEBULA, PayyePrefs.WALLPAPER_OBSIDIAN};
        new AlertDialog.Builder(this)
                .setTitle("Select Static Wallpaper")
                .setItems(labels, (d, which) -> {
                    prefs.setWallpaper(keys[which]);
                    buildSettingsList();
                })
                .show();
    }

    private void showThemeDialog() {
        String[] labels = {"Neon Eclipse", "Violet Dusk", "Moonlight Minimal"};
        String[] keys = {PayyePrefs.THEME_NEON_ECLIPSE, PayyePrefs.THEME_VIOLET_DUSK, PayyePrefs.THEME_MOONLIGHT};
        new AlertDialog.Builder(this)
                .setTitle("Select Theme")
                .setItems(labels, (d, which) -> {
                    prefs.setTheme(keys[which]);
                    buildSettingsList();
                })
                .show();
    }

    private void showAccentDialog() {
        String[] labels = {"Eclipse Purple (#7138FF)", "Neon Pink (#E15BFF)", "Lavender (#BBA9D8)", "Moonlight (#F3EFFF)"};
        String[] keys = {PayyePrefs.ACCENT_PURPLE, PayyePrefs.ACCENT_PINK, PayyePrefs.ACCENT_LAVENDER, PayyePrefs.ACCENT_MOONLIGHT};
        new AlertDialog.Builder(this)
                .setTitle("Select Accent Colour")
                .setItems(labels, (d, which) -> {
                    prefs.setAccent(keys[which]);
                    buildSettingsList();
                })
                .show();
    }

    private void showClockStyleDialog() {
        String[] labels = {"Eclipse Bold", "Minimalist Mono", "Stacked Cosmic"};
        String[] keys = {PayyePrefs.CLOCK_ECLIPSE_BOLD, PayyePrefs.CLOCK_MINIMAL_MONO, PayyePrefs.CLOCK_STACKED_COSMIC};
        new AlertDialog.Builder(this)
                .setTitle("Select Clock Style")
                .setItems(labels, (d, which) -> {
                    prefs.setClockStyle(keys[which]);
                    buildSettingsList();
                })
                .show();
    }

    private void showLayoutDialog() {
        String[] labels = {"2-Column Cards (Default)", "4-Column Compact Grid", "Minimalist List"};
        String[] keys = {PayyePrefs.LAYOUT_GRID_2, PayyePrefs.LAYOUT_GRID_4, PayyePrefs.LAYOUT_LIST};
        new AlertDialog.Builder(this)
                .setTitle("Home Screen Layout")
                .setItems(labels, (d, which) -> {
                    prefs.setHomeLayout(keys[which]);
                    buildSettingsList();
                })
                .show();
    }

    private void showManageHomeAppsDialog() {
        List<AppInfo> all = AppRepository.getAllInstalledApps(this);
        List<String> pinned = prefs.getHomePackages();
        String[] names = new String[all.size()];
        boolean[] checked = new boolean[all.size()];
        for (int i = 0; i < all.size(); i++) {
            names[i] = all.get(i).label;
            checked[i] = pinned.contains(all.get(i).packageName);
        }
        new AlertDialog.Builder(this)
                .setTitle("Pin Apps to Home Screen")
                .setMultiChoiceItems(names, checked, (d, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton("Save", (d, w) -> {
                    List<String> updated = new java.util.ArrayList<>();
                    for (int i = 0; i < all.size(); i++) {
                        if (checked[i]) {
                            updated.add(all.get(i).packageName);
                        }
                    }
                    prefs.setHomePackages(updated);
                    buildSettingsList();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void toggleFocusFromSettings() {
        if (prefs.isFocusActive()) {
            prefs.stopFocusMode();
            Toast.makeText(this, "Focus Mode ended", Toast.LENGTH_SHORT).show();
            buildSettingsList();
        } else {
            final String[] labels = {"15 minutes", "25 minutes", "45 minutes", "60 minutes", "Untimed Focus"};
            final int[] durations = {15, 25, 45, 60, 0};
            new AlertDialog.Builder(this)
                    .setTitle("Start Focus Mode")
                    .setItems(labels, (d, which) -> {
                        prefs.startFocusMode(durations[which]);
                        Toast.makeText(this, "Focus Mode started", Toast.LENGTH_SHORT).show();
                        buildSettingsList();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        }
    }

    private void showDistractingAppsDialog() {
        List<AppInfo> all = AppRepository.getAllInstalledApps(this);
        Set<String> distracting = prefs.getDistractingPackages();
        String[] names = new String[all.size()];
        boolean[] checked = new boolean[all.size()];
        for (int i = 0; i < all.size(); i++) {
            names[i] = all.get(i).label;
            checked[i] = distracting.contains(all.get(i).packageName);
        }
        new AlertDialog.Builder(this)
                .setTitle("Hide During Focus Mode")
                .setMultiChoiceItems(names, checked, (d, which, isChecked) -> checked[which] = isChecked)
                .setPositiveButton("Save", (d, w) -> {
                    Set<String> updated = new HashSet<>();
                    for (int i = 0; i < all.size(); i++) {
                        if (checked[i]) {
                            updated.add(all.get(i).packageName);
                        }
                    }
                    prefs.setDistractingPackages(updated);
                    buildSettingsList();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void openSystemSettings(String action) {
        try {
            Intent intent = new Intent(action);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "This shortcut is not supported on your device", Toast.LENGTH_SHORT).show();
        }
    }

    private void confirmResetDefaults() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.reset_defaults_title)
                .setMessage(R.string.reset_confirm_msg)
                .setPositiveButton("Reset", (d, w) -> {
                    prefs.resetAppearanceToDefaults();
                    Toast.makeText(this, R.string.reset_done, Toast.LENGTH_SHORT).show();
                    buildSettingsList();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private String formatWallpaperName(String key) {
        switch (key) {
            case PayyePrefs.WALLPAPER_HORIZON:
                return "Void Horizon";
            case PayyePrefs.WALLPAPER_NEBULA:
                return "Neon Nebula";
            case PayyePrefs.WALLPAPER_OBSIDIAN:
                return "Pure Obsidian";
            default:
                return "Cosmic Eclipse";
        }
    }

    private String formatThemeName(String key) {
        switch (key) {
            case PayyePrefs.THEME_VIOLET_DUSK:
                return "Violet Dusk";
            case PayyePrefs.THEME_MOONLIGHT:
                return "Moonlight Minimal";
            default:
                return "Neon Eclipse";
        }
    }

    private String formatAccentName(String key) {
        switch (key) {
            case PayyePrefs.ACCENT_PINK:
                return "Neon Pink";
            case PayyePrefs.ACCENT_LAVENDER:
                return "Lavender";
            case PayyePrefs.ACCENT_MOONLIGHT:
                return "Moonlight";
            default:
                return "Eclipse Purple";
        }
    }

    private String formatClockStyleName(String key) {
        switch (key) {
            case PayyePrefs.CLOCK_MINIMAL_MONO:
                return "Minimalist Mono";
            case PayyePrefs.CLOCK_STACKED_COSMIC:
                return "Stacked Cosmic";
            default:
                return "Eclipse Bold";
        }
    }

    private String formatLayoutName(String key) {
        switch (key) {
            case PayyePrefs.LAYOUT_GRID_4:
                return "4-Column Compact Grid";
            case PayyePrefs.LAYOUT_LIST:
                return "Minimalist List";
            default:
                return "2-Column Cards";
        }
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics());
    }
}
