package com.payye.os;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class AppDrawerAdapter extends RecyclerView.Adapter<AppDrawerAdapter.ViewHolder> {

    public interface OnDrawerActionListener {
        void onAppClick(AppInfo app);
        void onAppLongClick(AppInfo app);
    }

    private final List<AppInfo> allApps;
    private final List<AppInfo> filteredApps;
    private Set<String> pinnedPackages;
    private final OnDrawerActionListener listener;

    public AppDrawerAdapter(List<AppInfo> apps, Set<String> pinnedPackages, OnDrawerActionListener listener) {
        this.allApps = new ArrayList<>(apps);
        this.filteredApps = new ArrayList<>(apps);
        this.pinnedPackages = pinnedPackages;
        this.listener = listener;
    }

    public void updatePinned(Set<String> pinnedPackages) {
        this.pinnedPackages = pinnedPackages;
        notifyDataSetChanged();
    }

    public int filter(String query) {
        filteredApps.clear();
        if (query == null || query.trim().isEmpty()) {
            filteredApps.addAll(allApps);
        } else {
            String q = query.trim().toLowerCase(Locale.getDefault());
            for (AppInfo app : allApps) {
                if (app.label.toLowerCase(Locale.getDefault()).contains(q)
                        || app.packageName.toLowerCase(Locale.getDefault()).contains(q)) {
                    filteredApps.add(app);
                }
            }
        }
        notifyDataSetChanged();
        return filteredApps.size();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_app_drawer, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        AppInfo app = filteredApps.get(position);
        holder.label.setText(app.label);
        holder.icon.setImageDrawable(app.icon);
        boolean isPinned = pinnedPackages.contains(app.packageName);
        holder.tag.setVisibility(isPinned ? View.VISIBLE : View.GONE);

        holder.itemView.setOnClickListener(v -> listener.onAppClick(app));
        holder.itemView.setOnLongClickListener(v -> {
            listener.onAppLongClick(app);
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return filteredApps.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final ImageView icon;
        final TextView label;
        final TextView tag;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.ivDrawerIcon);
            label = itemView.findViewById(R.id.tvDrawerLabel);
            tag = itemView.findViewById(R.id.tvDrawerTag);
        }
    }
}
