package com.payye.os;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.Settings;
import android.provider.Telephony;
import android.widget.Toast;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class AppRepository {

    private AppRepository() {
    }

    public static List<AppInfo> getAllInstalledApps(Context context) {
        PackageManager pm = context.getPackageManager();
        Intent intent = new Intent(Intent.ACTION_MAIN, null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> resolved = pm.queryIntentActivities(intent, 0);
        List<AppInfo> apps = new ArrayList<>();
        Set<String> seenPackages = new HashSet<>();
        String selfPkg = context.getPackageName();

        for (ResolveInfo info : resolved) {
            if (info.activityInfo == null) continue;
            String pkg = info.activityInfo.packageName;
            if (pkg.equals(selfPkg) || seenPackages.contains(pkg)) continue;
            seenPackages.add(pkg);

            String label = info.loadLabel(pm).toString();
            Drawable icon = info.loadIcon(pm);
            apps.add(new AppInfo(label, pkg, icon));
        }
        Collections.sort(apps);
        return apps;
    }

    public static List<AppInfo> getHomeApps(Context context, PayyePrefs prefs) {
        PackageManager pm = context.getPackageManager();
        List<String> savedPackages = prefs.getHomePackages();
        boolean focusActive = prefs.isFocusActive();
        Set<String> distracting = focusActive ? prefs.getDistractingPackages() : Collections.emptySet();

        List<AppInfo> result = new ArrayList<>();
        for (String pkg : savedPackages) {
            if (focusActive && distracting.contains(pkg)) {
                continue;
            }
            AppInfo app = getAppInfoForPackage(pm, pkg);
            if (app != null) {
                result.add(app);
            }
        }
        return result;
    }

    public static AppInfo getAppInfoForPackage(PackageManager pm, String packageName) {
        try {
            Intent launch = pm.getLaunchIntentForPackage(packageName);
            if (launch == null) return null;
            ResolveInfo info = pm.resolveActivity(launch, 0);
            if (info == null) return null;
            String label = info.loadLabel(pm).toString();
            Drawable icon = info.loadIcon(pm);
            return new AppInfo(label, packageName, icon);
        } catch (Exception e) {
            return null;
        }
    }

    public static boolean isPackageInstalled(PackageManager pm, String packageName) {
        return pm.getLaunchIntentForPackage(packageName) != null;
    }

    public static List<String> detectDefaultEssentialPackages(Context context) {
        PackageManager pm = context.getPackageManager();
        Set<String> defaults = new LinkedHashSet<>();

        // 1. Phone / Dialer
        addIfLaunchable(pm, defaults, resolveIntentPackage(pm, new Intent(Intent.ACTION_DIAL)));
        addFirstInstalled(pm, defaults,
                "com.android.contacts", "com.huawei.contacts",
                "com.android.dialer", "com.google.android.dialer");

        // 2. Messages / SMS
        String defaultSms = Telephony.Sms.getDefaultSmsPackage(context);
        addIfLaunchable(pm, defaults, defaultSms);
        addFirstInstalled(pm, defaults,
                "com.android.mms", "com.google.android.apps.messaging");

        // 3. WhatsApp (if installed)
        addIfLaunchable(pm, defaults, "com.whatsapp");

        // 4. Snapchat (if installed)
        addIfLaunchable(pm, defaults, "com.snapchat.android");

        // 5. Brave Browser (if installed)
        addIfLaunchable(pm, defaults, "com.brave.browser");

        // 6. Music (system music or popular players if installed)
        Intent musicIntent = new Intent(Intent.ACTION_MAIN);
        musicIntent.addCategory(Intent.CATEGORY_APP_MUSIC);
        addIfLaunchable(pm, defaults, resolveIntentPackage(pm, musicIntent));
        addFirstInstalled(pm, defaults,
                "com.android.mediacenter",
                "com.google.android.apps.youtube.music",
                "com.spotify.music");

        // 7. Camera
        addIfLaunchable(pm, defaults, resolveIntentPackage(pm, new Intent(MediaStore.ACTION_IMAGE_CAPTURE)));
        addFirstInstalled(pm, defaults,
                "com.huawei.camera", "com.android.camera2", "com.android.camera");

        // 8. Gallery
        Intent galleryIntent = new Intent(Intent.ACTION_MAIN);
        galleryIntent.addCategory(Intent.CATEGORY_APP_GALLERY);
        addIfLaunchable(pm, defaults, resolveIntentPackage(pm, galleryIntent));
        addFirstInstalled(pm, defaults,
                "com.android.gallery3d", "com.google.android.apps.photos");

        // 9. PhonePe (optional, included automatically if installed)
        addIfLaunchable(pm, defaults, "com.phonepe.app");

        return new ArrayList<>(defaults);
    }

    public static Set<String> detectDefaultDistractingPackages(Context context) {
        PackageManager pm = context.getPackageManager();
        String[] candidates = {
                "com.snapchat.android",
                "com.instagram.android",
                "com.zhiliaoapp.musically",
                "com.ss.android.ugc.trill",
                "com.google.android.youtube",
                "com.facebook.katana",
                "com.twitter.android",
                "com.reddit.frontpage",
                "com.brave.browser"
        };
        Set<String> result = new HashSet<>();
        for (String pkg : candidates) {
            if (isPackageInstalled(pm, pkg)) {
                result.add(pkg);
            }
        }
        return result;
    }

    private static String resolveIntentPackage(PackageManager pm, Intent intent) {
        ResolveInfo info = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);
        if (info != null && info.activityInfo != null) {
            return info.activityInfo.packageName;
        }
        return null;
    }

    private static void addIfLaunchable(PackageManager pm, Set<String> target, String pkg) {
        if (pkg != null && isPackageInstalled(pm, pkg)) {
            target.add(pkg);
        }
    }

    private static void addFirstInstalled(PackageManager pm, Set<String> target, String... pkgs) {
        for (String pkg : pkgs) {
            if (isPackageInstalled(pm, pkg)) {
                target.add(pkg);
                return;
            }
        }
    }

    public static void launchApp(Context context, String packageName) {
        try {
            PackageManager pm = context.getPackageManager();
            Intent launchIntent = pm.getLaunchIntentForPackage(packageName);
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(launchIntent);
            } else {
                Toast.makeText(context, "App is not installed", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(context, "Unable to open application", Toast.LENGTH_SHORT).show();
        }
    }

    public static void openAppInfo(Context context, String packageName) {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + packageName));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(context, "Unable to open app info", Toast.LENGTH_SHORT).show();
        }
    }

    @SuppressLint("WrongConstant")
    public static void expandNotificationShade(Context context) {
        try {
            Object statusBarService = context.getSystemService("statusbar");
            Class<?> statusBarManager = Class.forName("android.app.StatusBarManager");
            Method expand = statusBarManager.getMethod("expandNotificationsPanel");
            expand.invoke(statusBarService);
        } catch (Exception e) {
            Toast.makeText(context, "Swipe down from the top bar for notifications", Toast.LENGTH_SHORT).show();
        }
    }
}
