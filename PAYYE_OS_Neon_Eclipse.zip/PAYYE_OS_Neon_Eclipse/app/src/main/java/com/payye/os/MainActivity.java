package com.payye.os;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private PayyePrefs prefs;
    private RelativeLayout rootLayout;
    private TextView tvGreeting;
    private TextView tvBattery;
    private TextView tvClock;
    private TextView tvClockSecondLine;
    private TextView tvDate;
    private TextView tvSlogan;
    private LinearLayout focusPill;
    private TextView tvFocusStatus;
    private RecyclerView rvHomeApps;
    private HomeAppsAdapter homeAdapter;

    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private boolean batteryReceiverRegistered = false;

    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            if (level >= 0 && scale > 0) {
                int pct = (int) ((level * 100f) / scale);
                boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                        || status == BatteryManager.BATTERY_STATUS_FULL;
                tvBattery.setText(charging ? "⚡ " + pct + "%" : pct + "%");
                tvBattery.setTextColor(pct <= 15 && !charging
                        ? getColor(R.color.battery_low)
                        : getColor(R.color.moonlight));
            }
        }
    };

    private final Runnable clockTicker = new Runnable() {
        @Override
        public void run() {
            updateClockDateAndFocus();
            uiHandler.postDelayed(this, 1000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = new PayyePrefs(this);
        prefs.ensureInitialized(this);

        rootLayout = findViewById(R.id.rootLayout);
        tvGreeting = findViewById(R.id.tvGreeting);
        tvBattery = findViewById(R.id.tvBattery);
        tvClock = findViewById(R.id.tvClock);
        tvClockSecondLine = findViewById(R.id.tvClockSecondLine);
        tvDate = findViewById(R.id.tvDate);
        tvSlogan = findViewById(R.id.tvSlogan);
        focusPill = findViewById(R.id.focusPill);
        tvFocusStatus = findViewById(R.id.tvFocusStatus);
        rvHomeApps = findViewById(R.id.rvHomeApps);

        ImageButton btnAddHomeApp = findViewById(R.id.btnAddHomeApp);
        ImageButton btnNotifications = findViewById(R.id.btnNotifications);
        ImageButton btnSearch = findViewById(R.id.btnSearch);
        ImageButton btnAppDrawer = findViewById(R.id.btnAppDrawer);
        ImageButton btnSettings = findViewById(R.id.btnSettings);

        homeAdapter = new HomeAppsAdapter(new ArrayList<>(), false, true, new HomeAppsAdapter.OnAppActionListener() {
            @Override
            public void onAppClick(AppInfo app) {
                AppRepository.launchApp(MainActivity.this, app.packageName);
            }

            @Override
            public void onAppLongClick(AppInfo app) {
                showHomeAppOptionsDialog(app);
            }
        });
        rvHomeApps.setAdapter(homeAdapter);

        focusPill.setOnClickListener(v -> handleFocusPillClick());
        btnAddHomeApp.setOnClickListener(v -> showAddAppDialog());
        btnNotifications.setOnClickListener(v -> AppRepository.expandNotificationShade(this));
        btnSearch.setOnClickListener(v -> openAppDrawer(true));
        btnAppDrawer.setOnClickListener(v -> openAppDrawer(false));
        btnSettings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyAppearance();
        refreshHomeApps();
        updateClockDateAndFocus();

        if (!batteryReceiverRegistered) {
            registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            batteryReceiverRegistered = true;
        }
        uiHandler.removeCallbacks(clockTicker);
        uiHandler.post(clockTicker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        uiHandler.removeCallbacks(clockTicker);
        if (batteryReceiverRegistered) {
            try {
                unregisterReceiver(batteryReceiver);
            } catch (IllegalArgumentException ignored) {
            }
            batteryReceiverRegistered = false;
        }
    }

    @Override
    public void onBackPressed() {
        // Launcher root ignores Back button so user stays on Home screen.
    }

    private void applyAppearance() {
        rootLayout.setBackgroundResource(prefs.getWallpaperDrawableRes());

        int accentColor = prefs.getAccentColorInt();
        String theme = prefs.getTheme();
        if (PayyePrefs.THEME_MOONLIGHT.equals(theme)) {
            tvSlogan.setTextColor(getColor(R.color.lavender));
        } else if (PayyePrefs.THEME_VIOLET_DUSK.equals(theme)) {
            tvSlogan.setTextColor(Color.parseColor("#9B86C4"));
        } else {
            tvSlogan.setTextColor(getColor(R.color.text_muted));
        }

        String clockStyle = prefs.getClockStyle();
        if (PayyePrefs.CLOCK_MINIMAL_MONO.equals(clockStyle)) {
            tvClock.setTypeface(Typeface.MONOSPACE, Typeface.NORMAL);
            tvClock.setTextSize(48f);
            tvClock.setTextColor(getColor(R.color.moonlight));
            tvClockSecondLine.setVisibility(View.GONE);
        } else if (PayyePrefs.CLOCK_STACKED_COSMIC.equals(clockStyle)) {
            tvClock.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
            tvClock.setTextSize(50f);
            tvClock.setTextColor(getColor(R.color.moonlight));
            tvClockSecondLine.setVisibility(View.VISIBLE);
            tvClockSecondLine.setTextColor(accentColor);
        } else {
            tvClock.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
            tvClock.setTextSize(54f);
            tvClock.setTextColor(getColor(R.color.moonlight));
            tvClockSecondLine.setVisibility(View.GONE);
        }
    }

    private void refreshHomeApps() {
        String layout = prefs.getHomeLayout();
        boolean showIcons = prefs.isShowIcons();
        boolean isList = PayyePrefs.LAYOUT_LIST.equals(layout);

        if (isList) {
            rvHomeApps.setLayoutManager(new LinearLayoutManager(this));
        } else if (PayyePrefs.LAYOUT_GRID_4.equals(layout)) {
            rvHomeApps.setLayoutManager(new GridLayoutManager(this, 4));
        } else {
            rvHomeApps.setLayoutManager(new GridLayoutManager(this, 2));
        }

        List<AppInfo> homeApps = AppRepository.getHomeApps(this, prefs);
        homeAdapter.updateData(homeApps, isList, showIcons);
    }

    private void updateClockDateAndFocus() {
        Date now = new Date();
        String clockStyle = prefs.getClockStyle();
        if (PayyePrefs.CLOCK_STACKED_COSMIC.equals(clockStyle)) {
            tvClock.setText(new SimpleDateFormat("HH", Locale.getDefault()).format(now));
            tvClockSecondLine.setText(new SimpleDateFormat("mm", Locale.getDefault()).format(now));
        } else {
            tvClock.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(now));
        }

        tvDate.setText(new SimpleDateFormat("EEEE • MMM dd", Locale.getDefault()).format(now).toUpperCase(Locale.getDefault()));

        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour >= 5 && hour < 12) {
            tvGreeting.setText("GOOD MORNING");
        } else if (hour >= 12 && hour < 17) {
            tvGreeting.setText("GOOD AFTERNOON");
        } else if (hour >= 17 && hour < 22) {
            tvGreeting.setText("GOOD EVENING");
        } else {
            tvGreeting.setText("LATE NIGHT");
        }

        boolean focusWasActive = prefs.isFocusActive();
        if (focusWasActive) {
            focusPill.setBackgroundResource(R.drawable.bg_focus_pill_active);
            long end = prefs.getFocusEndTimeMillis();
            if (end > 0L) {
                long remainingSec = Math.max(0L, (end - System.currentTimeMillis()) / 1000L);
                long mins = remainingSec / 60L;
                long secs = remainingSec % 60L;
                tvFocusStatus.setText(String.format(Locale.getDefault(), "FOCUS ACTIVE • %02d:%02d", mins, secs));
            } else {
                tvFocusStatus.setText("FOCUS ACTIVE • UNTIMED");
            }
            tvFocusStatus.setTextColor(getColor(R.color.moonlight));
        } else {
            focusPill.setBackgroundResource(R.drawable.bg_focus_pill);
            tvFocusStatus.setText(R.string.focus_off_label);
            tvFocusStatus.setTextColor(getColor(R.color.lavender));
        }
    }

    private void handleFocusPillClick() {
        if (prefs.isFocusActive()) {
            new AlertDialog.Builder(this)
                    .setTitle("Focus Mode Active")
                    .setMessage("Distracting apps are hidden from your home screen. Exit Focus Mode now?")
                    .setPositiveButton("Exit Focus Mode", (d, w) -> {
                        prefs.stopFocusMode();
                        updateClockDateAndFocus();
                        refreshHomeApps();
                        Toast.makeText(this, "Focus Mode ended", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Stay Focused", null)
                    .show();
        } else {
            final String[] labels = {"15 minutes", "25 minutes (Pomodoro)", "45 minutes", "60 minutes", "Untimed Focus"};
            final int[] durations = {15, 25, 45, 60, 0};
            new AlertDialog.Builder(this)
                    .setTitle("Start Focus Mode")
                    .setItems(labels, (d, which) -> {
                        prefs.startFocusMode(durations[which]);
                        updateClockDateAndFocus();
                        refreshHomeApps();
                        Toast.makeText(this, "Focus Mode started", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        }
    }

    private void showHomeAppOptionsDialog(AppInfo app) {
        String[] options = {"Remove from Home Screen", "App Info"};
        new AlertDialog.Builder(this)
                .setTitle(app.label)
                .setItems(options, (d, which) -> {
                    if (which == 0) {
                        prefs.removeHomePackage(app.packageName);
                        refreshHomeApps();
                        Toast.makeText(this, app.label + " removed from Home", Toast.LENGTH_SHORT).show();
                    } else {
                        AppRepository.openAppInfo(this, app.packageName);
                    }
                })
                .show();
    }

    private void showAddAppDialog() {
        List<AppInfo> all = AppRepository.getAllInstalledApps(this);
        List<String> currentHome = prefs.getHomePackages();
        List<AppInfo> candidates = new ArrayList<>();
        for (AppInfo app : all) {
            if (!currentHome.contains(app.packageName)) {
                candidates.add(app);
            }
        }
        if (candidates.isEmpty()) {
            Toast.makeText(this, "All installed apps are already on Home", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] labels = new String[candidates.size()];
        for (int i = 0; i < candidates.size(); i++) {
            labels[i] = candidates.get(i).label;
        }
        new AlertDialog.Builder(this)
                .setTitle("Add App to Home Screen")
                .setItems(labels, (d, which) -> {
                    AppInfo selected = candidates.get(which);
                    prefs.addHomePackage(selected.packageName);
                    refreshHomeApps();
                    Toast.makeText(this, selected.label + " added to Home", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void openAppDrawer(boolean focusSearch) {
        Intent intent = new Intent(this, AppDrawerActivity.class);
        intent.putExtra(AppDrawerActivity.EXTRA_FOCUS_SEARCH, focusSearch);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}
