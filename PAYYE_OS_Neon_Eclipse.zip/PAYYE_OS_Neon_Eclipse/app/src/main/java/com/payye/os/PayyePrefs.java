package com.payye.os;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PayyePrefs {
    private static final String PREFS_NAME = "payye_os_prefs";

    private static final String KEY_INITIALIZED = "initialized";
    private static final String KEY_WALLPAPER = "wallpaper";
    private static final String KEY_THEME = "theme";
    private static final String KEY_ACCENT = "accent";
    private static final String KEY_CLOCK_STYLE = "clock_style";
    private static final String KEY_HOME_LAYOUT = "home_layout";
    private static final String KEY_SHOW_ICONS = "show_icons";
    private static final String KEY_HOME_PACKAGES = "home_packages";

    private static final String KEY_FOCUS_ACTIVE = "focus_active";
    private static final String KEY_FOCUS_END_TIME = "focus_end_time";
    private static final String KEY_FOCUS_DURATION_MIN = "focus_duration_min";
    private static final String KEY_DISTRACTING_PACKAGES = "distracting_packages";

    // Wallpaper keys
    public static final String WALLPAPER_COSMIC = "cosmic_eclipse";
    public static final String WALLPAPER_HORIZON = "void_horizon";
    public static final String WALLPAPER_NEBULA = "neon_nebula";
    public static final String WALLPAPER_OBSIDIAN = "pure_obsidian";

    // Theme keys
    public static final String THEME_NEON_ECLIPSE = "neon_eclipse";
    public static final String THEME_VIOLET_DUSK = "violet_dusk";
    public static final String THEME_MOONLIGHT = "moonlight_minimal";

    // Accent keys
    public static final String ACCENT_PURPLE = "eclipse_purple";
    public static final String ACCENT_PINK = "neon_pink";
    public static final String ACCENT_LAVENDER = "lavender";
    public static final String ACCENT_MOONLIGHT = "moonlight";

    // Clock styles
    public static final String CLOCK_ECLIPSE_BOLD = "eclipse_bold";
    public static final String CLOCK_MINIMAL_MONO = "minimal_mono";
    public static final String CLOCK_STACKED_COSMIC = "stacked_cosmic";

    // Home layouts
    public static final String LAYOUT_GRID_2 = "grid_2";
    public static final String LAYOUT_GRID_4 = "grid_4";
    public static final String LAYOUT_LIST = "list";

    private final SharedPreferences prefs;

    public PayyePrefs(Context context) {
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public void ensureInitialized(Context context) {
        if (!prefs.getBoolean(KEY_INITIALIZED, false)) {
            List<String> defaults = AppRepository.detectDefaultEssentialPackages(context);
            Set<String> distracting = AppRepository.detectDefaultDistractingPackages(context);
            prefs.edit()
                    .putBoolean(KEY_INITIALIZED, true)
                    .putString(KEY_WALLPAPER, WALLPAPER_COSMIC)
                    .putString(KEY_THEME, THEME_NEON_ECLIPSE)
                    .putString(KEY_ACCENT, ACCENT_PURPLE)
                    .putString(KEY_CLOCK_STYLE, CLOCK_ECLIPSE_BOLD)
                    .putString(KEY_HOME_LAYOUT, LAYOUT_GRID_2)
                    .putBoolean(KEY_SHOW_ICONS, true)
                    .putString(KEY_HOME_PACKAGES, TextUtils.join("|", defaults))
                    .putStringSet(KEY_DISTRACTING_PACKAGES, distracting)
                    .putInt(KEY_FOCUS_DURATION_MIN, 25)
                    .apply();
        }
    }

    public String getWallpaper() {
        return prefs.getString(KEY_WALLPAPER, WALLPAPER_COSMIC);
    }

    public void setWallpaper(String wallpaper) {
        prefs.edit().putString(KEY_WALLPAPER, wallpaper).apply();
    }

    public int getWallpaperDrawableRes() {
        switch (getWallpaper()) {
            case WALLPAPER_HORIZON:
                return R.drawable.wallpaper_void_horizon;
            case WALLPAPER_NEBULA:
                return R.drawable.wallpaper_neon_nebula;
            case WALLPAPER_OBSIDIAN:
                return R.drawable.wallpaper_pure_obsidian;
            case WALLPAPER_COSMIC:
            default:
                return R.drawable.wallpaper_cosmic_eclipse;
        }
    }

    public String getTheme() {
        return prefs.getString(KEY_THEME, THEME_NEON_ECLIPSE);
    }

    public void setTheme(String theme) {
        prefs.edit().putString(KEY_THEME, theme).apply();
    }

    public String getAccent() {
        return prefs.getString(KEY_ACCENT, ACCENT_PURPLE);
    }

    public void setAccent(String accent) {
        prefs.edit().putString(KEY_ACCENT, accent).apply();
    }

    public int getAccentColorInt() {
        switch (getAccent()) {
            case ACCENT_PINK:
                return Color.parseColor("#E15BFF");
            case ACCENT_LAVENDER:
                return Color.parseColor("#BBA9D8");
            case ACCENT_MOONLIGHT:
                return Color.parseColor("#F3EFFF");
            case ACCENT_PURPLE:
            default:
                return Color.parseColor("#7138FF");
        }
    }

    public String getClockStyle() {
        return prefs.getString(KEY_CLOCK_STYLE, CLOCK_ECLIPSE_BOLD);
    }

    public void setClockStyle(String style) {
        prefs.edit().putString(KEY_CLOCK_STYLE, style).apply();
    }

    public String getHomeLayout() {
        return prefs.getString(KEY_HOME_LAYOUT, LAYOUT_GRID_2);
    }

    public void setHomeLayout(String layout) {
        prefs.edit().putString(KEY_HOME_LAYOUT, layout).apply();
    }

    public boolean isShowIcons() {
        return prefs.getBoolean(KEY_SHOW_ICONS, true);
    }

    public void setShowIcons(boolean show) {
        prefs.edit().putBoolean(KEY_SHOW_ICONS, show).apply();
    }

    public List<String> getHomePackages() {
        String raw = prefs.getString(KEY_HOME_PACKAGES, "");
        if (TextUtils.isEmpty(raw)) {
            return new ArrayList<>();
        }
        return new ArrayList<>(Arrays.asList(raw.split("\\|")));
    }

    public void setHomePackages(List<String> packages) {
        prefs.edit().putString(KEY_HOME_PACKAGES, TextUtils.join("|", packages)).apply();
    }

    public void addHomePackage(String packageName) {
        List<String> current = getHomePackages();
        if (!current.contains(packageName)) {
            current.add(packageName);
            setHomePackages(current);
        }
    }

    public void removeHomePackage(String packageName) {
        List<String> current = getHomePackages();
        if (current.remove(packageName)) {
            setHomePackages(current);
        }
    }

    public boolean isHomePackage(String packageName) {
        return getHomePackages().contains(packageName);
    }

    public boolean isFocusActive() {
        boolean active = prefs.getBoolean(KEY_FOCUS_ACTIVE, false);
        if (!active) return false;
        long end = prefs.getLong(KEY_FOCUS_END_TIME, 0L);
        if (end > 0L && System.currentTimeMillis() >= end) {
            stopFocusMode();
            return false;
        }
        return true;
    }

    public long getFocusEndTimeMillis() {
        return prefs.getLong(KEY_FOCUS_END_TIME, 0L);
    }

    public int getFocusDurationMinutes() {
        return prefs.getInt(KEY_FOCUS_DURATION_MIN, 25);
    }

    public void setFocusDurationMinutes(int minutes) {
        prefs.edit().putInt(KEY_FOCUS_DURATION_MIN, minutes).apply();
    }

    public void startFocusMode(int durationMinutes) {
        long end = durationMinutes > 0
                ? System.currentTimeMillis() + (durationMinutes * 60_000L)
                : 0L;
        prefs.edit()
                .putBoolean(KEY_FOCUS_ACTIVE, true)
                .putInt(KEY_FOCUS_DURATION_MIN, durationMinutes)
                .putLong(KEY_FOCUS_END_TIME, end)
                .apply();
    }

    public void stopFocusMode() {
        prefs.edit()
                .putBoolean(KEY_FOCUS_ACTIVE, false)
                .putLong(KEY_FOCUS_END_TIME, 0L)
                .apply();
    }

    public Set<String> getDistractingPackages() {
        return new HashSet<>(prefs.getStringSet(KEY_DISTRACTING_PACKAGES, new HashSet<>()));
    }

    public void setDistractingPackages(Set<String> packages) {
        prefs.edit().putStringSet(KEY_DISTRACTING_PACKAGES, new HashSet<>(packages)).apply();
    }

    public void resetAppearanceToDefaults() {
        prefs.edit()
                .putString(KEY_WALLPAPER, WALLPAPER_COSMIC)
                .putString(KEY_THEME, THEME_NEON_ECLIPSE)
                .putString(KEY_ACCENT, ACCENT_PURPLE)
                .putString(KEY_CLOCK_STYLE, CLOCK_ECLIPSE_BOLD)
                .putString(KEY_HOME_LAYOUT, LAYOUT_GRID_2)
                .putBoolean(KEY_SHOW_ICONS, true)
                .apply();
    }
}
