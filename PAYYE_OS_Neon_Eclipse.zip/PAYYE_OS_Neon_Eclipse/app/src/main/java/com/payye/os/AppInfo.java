package com.payye.os;

import android.graphics.drawable.Drawable;

public class AppInfo implements Comparable<AppInfo> {
    public final String label;
    public final String packageName;
    public final Drawable icon;

    public AppInfo(String label, String packageName, Drawable icon) {
        this.label = label != null ? label : packageName;
        this.packageName = packageName;
        this.icon = icon;
    }

    @Override
    public int compareTo(AppInfo other) {
        return this.label.compareToIgnoreCase(other.label);
    }
}
