package com.payye.os;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AppDrawerActivity extends AppCompatActivity {

    public static final String EXTRA_FOCUS_SEARCH = "extra_focus_search";

    private PayyePrefs prefs;
    private AppDrawerAdapter adapter;
    private TextView tvAppCount;
    private TextView tvEmptyApps;
    private EditText etSearchApps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_drawer);

        prefs = new PayyePrefs(this);

        ImageButton btnBack = findViewById(R.id.btnDrawerBack);
        tvAppCount = findViewById(R.id.tvAppCount);
        tvEmptyApps = findViewById(R.id.tvEmptyApps);
        etSearchApps = findViewById(R.id.etSearchApps);
        RecyclerView rvAllApps = findViewById(R.id.rvAllApps);

        btnBack.setOnClickListener(v -> finish());

        List<AppInfo> installedApps = AppRepository.getAllInstalledApps(this);
        Set<String> pinned = new HashSet<>(prefs.getHomePackages());
        tvAppCount.setText(installedApps.size() + " apps installed • Long-press to pin");

        adapter = new AppDrawerAdapter(installedApps, pinned, new AppDrawerAdapter.OnDrawerActionListener() {
            @Override
            public void onAppClick(AppInfo app) {
                AppRepository.launchApp(AppDrawerActivity.this, app.packageName);
            }

            @Override
            public void onAppLongClick(AppInfo app) {
                showDrawerOptions(app);
            }
        });

        rvAllApps.setLayoutManager(new LinearLayoutManager(this));
        rvAllApps.setAdapter(adapter);

        etSearchApps.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int countMatched = adapter.filter(s.toString());
                tvEmptyApps.setVisibility(countMatched == 0 ? View.VISIBLE : View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        if (getIntent().getBooleanExtra(EXTRA_FOCUS_SEARCH, false)) {
            etSearchApps.requestFocus();
            etSearchApps.postDelayed(() -> {
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) {
                    imm.showSoftInput(etSearchApps, InputMethodManager.SHOW_IMPLICIT);
                }
            }, 150);
        }
    }

    private void showDrawerOptions(AppInfo app) {
        boolean isPinned = prefs.isHomePackage(app.packageName);
        String pinLabel = isPinned ? "Remove from Home Screen" : "Add to Home Screen";
        String[] options = {pinLabel, "App Info"};

        new AlertDialog.Builder(this)
                .setTitle(app.label)
                .setItems(options, (d, which) -> {
                    if (which == 0) {
                        if (isPinned) {
                            prefs.removeHomePackage(app.packageName);
                            Toast.makeText(this, app.label + " removed from Home", Toast.LENGTH_SHORT).show();
                        } else {
                            prefs.addHomePackage(app.packageName);
                            Toast.makeText(this, app.label + " added to Home", Toast.LENGTH_SHORT).show();
                        }
                        adapter.updatePinned(new HashSet<>(prefs.getHomePackages()));
                    } else {
                        AppRepository.openAppInfo(this, app.packageName);
                    }
                })
                .show();
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}
