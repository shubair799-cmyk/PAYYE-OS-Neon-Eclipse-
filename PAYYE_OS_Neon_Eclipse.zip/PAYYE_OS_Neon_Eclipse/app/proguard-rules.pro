# ProGuard rules for PAYYE OS — Neon Eclipse
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-dontwarn android.app.StatusBarManager
