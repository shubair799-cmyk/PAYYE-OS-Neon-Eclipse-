# PAYYE OS — Neon Eclipse

**YOUR PHONE. YOUR WORLD.**

A lightweight, minimalist Android Home Launcher in Java built specifically for the **HONOR 8S (KSA-LX9)** running **Android 9 (API 28)** with **2 GB RAM**, **armeabi-v7a** 32-bit ARM architecture, and a **1520 × 720** display.

---

## Key Features

- **Neon Eclipse Visual Identity**: Void Black (`#0B0715`), Deep Violet (`#241044`), Eclipse Purple (`#7138FF`), Neon Pink (`#E15BFF`), Lavender (`#BBA9D8`), Moonlight (`#F3EFFF`), and Surface (`#171020`).
- **Low-RAM Static Wallpapers**: 4 vector/gradient XML wallpapers (`Cosmic Eclipse`, `Void Horizon`, `Neon Nebula`, `Pure Obsidian`) with zero heavy bitmaps.
- **Home Screen**: Large digital clock (3 styles: Eclipse Bold, Minimalist Mono, Stacked Cosmic), date & day, live battery percentage, time-aware greeting, Focus Mode indicator, customizable app grid (2-column cards, 4-column compact grid, or minimalist list), and bottom dock (Notifications, Search, App Drawer, Settings).
- **Dynamic Installed App Detection**: Automatically detects installed Dialer/Phone, SMS/Messages, WhatsApp, Snapchat, Brave Browser, Music, Camera, Gallery, and optional PhonePe without hardcoding or assuming apps exist.
- **Focus Mode**: Hides user-selected distracting apps from the Home Screen with an optional countdown timer (15m, 25m, 45m, 60m, or Untimed) and one-tap exit.
- **PAYYE Customisation**: Wallpaper, theme, accent colour, clock style, layout, icon visibility, home app pinning, Android system shortcuts (Sound, Wi-Fi, Bluetooth, Notifications, Default Home App), and Reset to Default Appearance.

---

## Option 1: Build APK Automatically with GitHub Actions (No Local Android Studio Required)

1. Create a new GitHub repository and push the contents of this project folder.
2. Open the **Actions** tab on GitHub and run **Build PAYYE OS Debug APK** (or it runs automatically on push to `main`/`master`).
3. Download the `payye-os-neon-eclipse-debug-apk` artifact ZIP and extract `app-debug.apk`.

---

## Option 2: Build in Android Studio

1. Extract the project ZIP and open the `PAYYE_OS_Neon_Eclipse` folder in **Android Studio** (Hedgehog / Iguana or newer with JDK 17).
2. Let Android Studio sync Gradle (`Gradle 8.2`, `AGP 8.2.2`, `compileSdk 34`, `minSdk 28`).
3. Go to **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Locate the output APK at `app/build/outputs/apk/debug/app-debug.apk`.

---

## Installing on HONOR 8S (KSA-LX9)

1. Transfer `app-debug.apk` to your HONOR 8S (or install via USB debugging: `adb install -r app/build/outputs/apk/debug/app-debug.apk`).
2. On your phone, open the APK and allow **Install unknown apps** if prompted.
3. Open **Settings → Apps → Default apps → Home app** (or use **Set Default Home Launcher** inside PAYYE Customisation) and select **PAYYE OS**.
4. Press the Home button to enter **PAYYE OS — Neon Eclipse**.
